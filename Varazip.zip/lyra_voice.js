
const recognition = new (window.SpeechRecognition || window.webkitSpeechRecognition)();
const synth = window.speechSynthesis;

function startListening() {
    recognition.start();
}

recognition.onresult = function(event) {
    const text = event.results[0][0].transcript;
    document.getElementById('transcript').innerText = "You: " + text;
    getLyraResponse(text);
};

function getLyraResponse(text) {
    let reply = "Hello, I am Lyra. You said: " + text;
    document.getElementById('response').innerText = reply;

    const utterThis = new SpeechSynthesisUtterance(reply);
    synth.speak(utterThis);
}
