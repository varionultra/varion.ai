
function toggleLyra() {
  const box = document.getElementById('lyra-box');
  box.style.display = box.style.display === 'none' ? 'block' : 'none';
}

document.getElementById('lyra-input').addEventListener('keydown', async function(event) {
  if (event.key === 'Enter') {
    const input = this.value;
    const messagesDiv = document.getElementById('lyra-messages');
    messagesDiv.innerHTML += `<div><b>You:</b> ${input}</div>`;
    this.value = '';
    
    const response = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${OPENAI_API_KEY}`
      },
      body: JSON.stringify({
        model: "gpt-3.5-turbo",
        messages: [{ role: "user", content: input }]
      })
    });
    
    const data = await response.json();
    const reply = data.choices?.[0]?.message?.content || "Sorry, Lyra is thinking...";
    messagesDiv.innerHTML += `<div><b>Lyra:</b> ${reply}</div>`;
    messagesDiv.scrollTop = messagesDiv.scrollHeight;
  }
});
